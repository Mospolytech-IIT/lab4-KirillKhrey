from functions import (
    check_positive, divide, safe_divide, process_value,
    calculate, check_range, evaluate_conditions, generate_exceptions, custom_exception_function
)
from functions import demo_check_positive, demo_divide, demo_check_range

# Шаг 9: Функция, которая последовательно вызывает все функции
def run_all_functions():
    """Запускает все функции последовательно для демонстрации работы исключений."""
    try:
        print("Тестирование check_positive(5):")
        check_positive(5)  # Положительное значение
        print("\nТестирование divide(10, 1):")
        divide(10, 1)  # Деление без ошибок
        print("\nТестирование safe_divide(10, 1):")
        safe_divide(10, 1)  # Без ошибки
        print("\nТестирование process_value(-3):")
        process_value(-3)  # Отрицательное значение
        print("\nТестирование calculate(10, 1):")
        calculate(10, 1)  # Должен вернуться корректный результат
        print("\nТестирование check_range(99):")
        check_range(99)  # В пределах диапазона
        print("\nТестирование evaluate_conditions(200):")
        evaluate_conditions(200)  # Выбросит ошибку диапазона
        print("\nТестирование generate_exceptions(1):")
        generate_exceptions(1)  # Не должно выбрасывать ошибку
        print("\nТестирование custom_exception_function(10):")
        custom_exception_function(10)  # Не должно выбрасывать исключение
        print("\nТестирование demo_check_positive():")
        demo_check_positive()  # Демонстрация ошибки при отрицательном значении
        print("\nТестирование demo_divide():")
        demo_divide()  # Демонстрация ошибки деления на ноль
        print("\nТестирование demo_check_range():")
        demo_check_range()  # Демонстрация ошибки диапазона
    except Exception as e:
        print(f"Ошибка в основной функции: {e}")
    finally:
        print("Все функции завершены корректно.")

if __name__ == "__main__":
    run_all_functions()
