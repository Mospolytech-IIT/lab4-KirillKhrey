from exceptions import NegativeValueError, DivisionByZeroError, OutOfRangeError

# Шаг 1: Две функции, которые выбрасывают исключения при определенных значениях
def check_positive(value):
    """Проверяет, является ли значение положительным."""
    if value < 0:
        raise NegativeValueError("Значение не может быть отрицательным.")
    print(f"Значение {value} является положительным.")

def divide(a, b):
    """Выполняет деление и выбрасывает исключение, если делитель равен нулю."""
    if b == 0:
        raise DivisionByZeroError("Деление на ноль недопустимо.")
    result = a / b
    print(f"Результат деления {a} на {b}: {result}")
    return result


# Шаг 2: Функция с одним обработчиком исключений общего типа
def safe_divide(a, b):
    """Выполняет деление с обработкой исключений общего типа."""
    try:
        result = divide(a, b)
        print(f"Результат safe_divide: {result}")
    except Exception as e:
        print(f"Произошла ошибка: {e}")


# Шаг 3: Функция с обработчиком исключений и блоком finally
def process_value(value):
    """Проверяет положительность значения и использует блок finally для завершения."""
    try:
        check_positive(value)
    except Exception as e:
        print(f"Произошла ошибка: {e}")
    finally:
        print("Завершение проверки положительности значения.")


# Шаг 4: Три функции с несколькими обработчиками исключений, используя пользовательские исключения
def calculate(a, b):
    """Выполняет деление и проверку диапазона результата."""
    try:
        result = divide(a, b)
        if not (1 <= result <= 100):
            raise OutOfRangeError("Результат вне допустимого диапазона (1-100).")
        print(f"Результат операции calculate: {result}")
        return result
    except DivisionByZeroError as e:
        print(f"Ошибка деления: {e}")
    except OutOfRangeError as e:
        print(f"Ошибка диапазона: {e}")
    finally:
        print("Завершение операции деления с проверкой диапазона.")

def check_range(value):
    """Проверяет, что значение в диапазоне 1-100."""
    try:
        if value < 1 or value > 100:
            raise OutOfRangeError("Значение вне допустимого диапазона (1-100).")
        print(f"Значение {value} в допустимом диапазоне.")
    except OutOfRangeError as e:
        print(f"Ошибка диапазона: {e}")
    finally:
        print("Завершение проверки диапазона.")

def evaluate_conditions(value):
    """Проверяет разные условия на значение и выбрасывает исключения."""
    try:
        check_positive(value)
        check_range(value)
    except NegativeValueError as e:
        print(f"Ошибка отрицательного значения: {e}")
    except OutOfRangeError as e:
        print(f"Ошибка диапазона: {e}")
    finally:
        print("Завершение проверки условий.")


# Шаг 5: Функция с генерацией и обработкой исключений
def generate_exceptions(value):
    """Выбрасывает и обрабатывает исключения для различных условий."""
    try:
        if value < 0:
            raise NegativeValueError("Отрицательное значение.")
        elif value == 0:
            raise DivisionByZeroError("Значение не должно быть нулем.")
        elif value > 100:
            raise OutOfRangeError("Значение слишком большое.")
        print(f"Значение {value} прошло все проверки.")
    except NegativeValueError as e:
        print(f"Обработка отрицательного значения: {e}")
    except DivisionByZeroError as e:
        print(f"Обработка деления на ноль: {e}")
    except OutOfRangeError as e:
        print(f"Обработка значения вне диапазона: {e}")
    finally:
        print("Завершение генерации и обработки исключений.")


# Шаг 7: Функция с пользовательским исключением
def custom_exception_function(value):
    """Выбрасывает NegativeValueError для отрицательных значений."""
    try:
        check_positive(value)
    except NegativeValueError as e:
        print(f"Обработка пользовательского исключения: {e}")
    finally:
        print("Завершение проверки пользовательского исключения.")


# Шаг 8: Функции, демонстрирующие работу исключений

def demo_check_positive():
    """Демонстрация выбрасывания исключения NegativeValueError."""
    try:
        check_positive(-1)
    except NegativeValueError as e:
        print(f"Демонстрация: {e}")

def demo_divide():
    """Демонстрация выбрасывания исключения DivisionByZeroError."""
    try:
        divide(10, 0)
    except DivisionByZeroError as e:
        print(f"Демонстрация: {e}")

def demo_check_range():
    """Демонстрация выбрасывания исключения OutOfRangeError."""
    try:
        check_range(150)
    except OutOfRangeError as e:
        print(f"Демонстрация: {e}")
