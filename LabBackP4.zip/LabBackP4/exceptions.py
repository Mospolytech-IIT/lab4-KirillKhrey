# Шаг 6: Определение пользовательских исключений

class NegativeValueError(Exception):
    """Исключение для отрицательных значений."""
    pass

class DivisionByZeroError(Exception):
    """Исключение для деления на ноль."""
    pass

class OutOfRangeError(Exception):
    """Исключение для значений вне допустимого диапазона."""
    pass
